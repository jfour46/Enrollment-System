
package AdminPackage;

import AdminPackage.AdminFrame;
import enrollmentsystem.DAO;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import enrollmentsystem.OptionFrame;


public class AdminLogin extends javax.swing.JFrame {

  
    public AdminLogin() {
        initComponents();
        
    }
    AdminFrame adminFra = new AdminFrame();
    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        userAdminFld = new javax.swing.JTextField();
        passAdminFld = new javax.swing.JPasswordField();
        checkBoxAdmin = new javax.swing.JCheckBox();
        loginAdminBtn = new javax.swing.JButton();
        cancelAdminBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\KATOLIKO AKO\\Pictures\\ForEnrollPhoto\\ISUFST logo.png")); // NOI18N

        jButton1.setBackground(new java.awt.Color(103, 239, 93));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setText("<");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(128, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(103, 103, 103)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(204, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 480, 510));

        jPanel2.setBackground(new java.awt.Color(234, 230, 230));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Login");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 14, 454, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel2.setText("Username :");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 162, 121, 34));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel3.setText("Password :");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 249, 121, 34));

        userAdminFld.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jPanel2.add(userAdminFld, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 248, 43));

        passAdminFld.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jPanel2.add(passAdminFld, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 246, 248, 40));

        checkBoxAdmin.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        checkBoxAdmin.setText("Show Password");
        checkBoxAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBoxAdminActionPerformed(evt);
            }
        });
        jPanel2.add(checkBoxAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(252, 298, 161, -1));

        loginAdminBtn.setBackground(new java.awt.Color(234, 138, 138));
        loginAdminBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        loginAdminBtn.setText("Login");
        loginAdminBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginAdminBtnActionPerformed(evt);
            }
        });
        jPanel2.add(loginAdminBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 390, 160, 50));

        cancelAdminBtn.setBackground(new java.awt.Color(50, 153, 255));
        cancelAdminBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cancelAdminBtn.setText("Cancel");
        cancelAdminBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelAdminBtnActionPerformed(evt);
            }
        });
        jPanel2.add(cancelAdminBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 160, 50));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(476, 0, 460, 520));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cancelAdminBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelAdminBtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_cancelAdminBtnActionPerformed

    private void loginAdminBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginAdminBtnActionPerformed
       String username = AdminLogin.userAdminFld.getText();
        String password = AdminLogin.passAdminFld.getText();
            
        if(username.equals("Admin") && password.equals("Admin123")){
                JOptionPane.showMessageDialog(null,"Successfully Login!!");
                adminFra.setVisible(true);
                this.dispose();
            }
        else{
                JOptionPane.showMessageDialog(null,"Wrong Username or Password please Try again!");
            }
    }//GEN-LAST:event_loginAdminBtnActionPerformed

    private void checkBoxAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBoxAdminActionPerformed
       
        if(checkBoxAdmin.isSelected()){
            passAdminFld.setEchoChar((char)0);
        }
        else{
            passAdminFld.setEchoChar('*');
        }
    }//GEN-LAST:event_checkBoxAdminActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        OptionFrame op = new OptionFrame();
        op.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton cancelAdminBtn;
    private javax.swing.JCheckBox checkBoxAdmin;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel2;
    public static javax.swing.JButton loginAdminBtn;
    public static javax.swing.JPasswordField passAdminFld;
    public static javax.swing.JTextField userAdminFld;
    // End of variables declaration//GEN-END:variables
}
