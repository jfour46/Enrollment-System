
package AdminPackage;

import enrollmentsystem.DAO;
import enrollmentsystem.DbConnection;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.Vector;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;


public class AdminFrame extends javax.swing.JFrame {

    Connection conn = null;
    PreparedStatement ps;
    ResultSet rs;
   
    public AdminFrame() {
        initComponents();
        studentShowData();
        subjectShowData();
        instructorShowData();
        
    }
    
    public void studentShowData(){
        try{
            DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
            dtm.setRowCount(0);
            conn = DbConnection.getConnection();
            Statement s = conn.createStatement();
            rs = s.executeQuery("SELECT * FROM student");
            
            while(rs.next()){
                Vector v = new Vector();
                v.add(rs.getString(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                
                dtm.addRow(v);
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    public void subjectShowData(){
        try{
            DefaultTableModel dtm = (DefaultTableModel) subjectTable.getModel();
            dtm.setRowCount(0);
            conn = DbConnection.getConnection();
            Statement s = conn.createStatement();
            rs = s.executeQuery("SELECT * FROM subject");
            
            while(rs.next()){
                Vector v = new Vector();
                v.add(rs.getString(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                
                
                dtm.addRow(v);
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    public void instructorShowData(){
        try{
            DefaultTableModel dtm = (DefaultTableModel) instructorTable.getModel();
            dtm.setRowCount(0);
            conn = DbConnection.getConnection();
            Statement s = conn.createStatement();
            rs = s.executeQuery("SELECT * FROM instructor");
            
            while(rs.next()){
                Vector v = new Vector();
                v.add(rs.getString(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                
                
                dtm.addRow(v);
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
    
    
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        parentPnl = new javax.swing.JPanel();
        subjectPnl = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        subjectCode = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        subjectDescriptive = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        subjectPre = new javax.swing.JTextField();
        subjectCredit = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        subjectUnits = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        subjectAddBtn = new javax.swing.JButton();
        subjectDeleteBtn = new javax.swing.JButton();
        subjectUpdateBtn = new javax.swing.JButton();
        subjectSearchFld = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        subjectTable = new javax.swing.JTable();
        instructorPnl = new javax.swing.JPanel();
        studentPnl1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        instructorFirstnameFld = new javax.swing.JTextField();
        instructorAgeFld = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        instructorLastnameFld = new javax.swing.JTextField();
        instructorIdFld = new javax.swing.JTextField();
        instructorGenderFld = new javax.swing.JTextField();
        instructorUpdateBtn = new javax.swing.JButton();
        instructorAddBtn = new javax.swing.JButton();
        instructorDeleteBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        instructorTable = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        instructorSearchFld = new javax.swing.JTextField();
        studentPnl = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        studentFirstnameFld = new javax.swing.JTextField();
        studentAgeFld = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        studentLastnameFld = new javax.swing.JTextField();
        studentIdFld = new javax.swing.JTextField();
        studentGenderFld = new javax.swing.JTextField();
        studentUpdateBtn = new javax.swing.JButton();
        studentAddBtn = new javax.swing.JButton();
        studentDeleteBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        studentSearchFld = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        studentUsernameFld = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        studentPasswordFld = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        parentPnl.setLayout(new java.awt.CardLayout());

        subjectPnl.setBackground(new java.awt.Color(171, 208, 245));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 32)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Subject");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel17.setText("Subject Code:");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setText("Descriptive :");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setText("Pre-req.");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setText("Credit :");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel21.setText("Units");

        subjectAddBtn.setBackground(new java.awt.Color(237, 139, 139));
        subjectAddBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectAddBtn.setText("Add");
        subjectAddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectAddBtnActionPerformed(evt);
            }
        });

        subjectDeleteBtn.setBackground(new java.awt.Color(103, 242, 94));
        subjectDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectDeleteBtn.setText("Delete");
        subjectDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectDeleteBtnActionPerformed(evt);
            }
        });

        subjectUpdateBtn.setBackground(new java.awt.Color(51, 153, 255));
        subjectUpdateBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectUpdateBtn.setText("Update");
        subjectUpdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectUpdateBtnActionPerformed(evt);
            }
        });

        subjectSearchFld.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        subjectSearchFld.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                subjectSearchFldKeyPressed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setText("Search Descriptive :");

        subjectTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "SubCode", "Descriptive", " Units", "Pre-req", "Credit"
            }
        ));
        subjectTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                subjectTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(subjectTable);

        javax.swing.GroupLayout subjectPnlLayout = new javax.swing.GroupLayout(subjectPnl);
        subjectPnl.setLayout(subjectPnlLayout);
        subjectPnlLayout.setHorizontalGroup(
            subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subjectPnlLayout.createSequentialGroup()
                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(subjectPnlLayout.createSequentialGroup()
                        .addGap(389, 389, 389)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(subjectPnlLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 896, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(subjectPnlLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(subjectPnlLayout.createSequentialGroup()
                                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(subjectCode, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(subjectUnits, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(subjectDescriptive, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(41, 41, 41)
                                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(subjectPnlLayout.createSequentialGroup()
                                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(subjectPre, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(subjectPnlLayout.createSequentialGroup()
                                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(subjectCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(subjectPnlLayout.createSequentialGroup()
                                        .addComponent(subjectAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(61, 61, 61)
                                        .addComponent(subjectDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(49, 49, 49)
                                        .addComponent(subjectUpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, subjectPnlLayout.createSequentialGroup()
                                .addComponent(jLabel22)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(subjectSearchFld, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(378, 378, 378)))))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        subjectPnlLayout.setVerticalGroup(
            subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subjectPnlLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(subjectCode, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(subjectPre, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(subjectDescriptive, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(subjectCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(subjectUnits, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(subjectAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(subjectDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(subjectUpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(45, 45, 45)
                .addGroup(subjectPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(subjectSearchFld, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        parentPnl.add(subjectPnl, "card3");

        studentPnl1.setBackground(new java.awt.Color(171, 208, 244));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 32)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Instructor");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Age :");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("Id Number :");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setText("Lastname :");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Gender :");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setText("Firstname :");

        instructorUpdateBtn.setBackground(new java.awt.Color(50, 153, 255));
        instructorUpdateBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        instructorUpdateBtn.setText("Update");
        instructorUpdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                instructorUpdateBtnActionPerformed(evt);
            }
        });

        instructorAddBtn.setBackground(new java.awt.Color(234, 138, 138));
        instructorAddBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        instructorAddBtn.setText("Add");
        instructorAddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                instructorAddBtnActionPerformed(evt);
            }
        });

        instructorDeleteBtn.setBackground(new java.awt.Color(103, 239, 93));
        instructorDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        instructorDeleteBtn.setText("Delete");
        instructorDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                instructorDeleteBtnActionPerformed(evt);
            }
        });

        instructorTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Number", "Lastname", "Firstname", "Age", "Gender"
            }
        ));
        instructorTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                instructorTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(instructorTable);

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setText("Search Name :");

        instructorSearchFld.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        instructorSearchFld.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                instructorSearchFldKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout studentPnl1Layout = new javax.swing.GroupLayout(studentPnl1);
        studentPnl1.setLayout(studentPnl1Layout);
        studentPnl1Layout.setHorizontalGroup(
            studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentPnl1Layout.createSequentialGroup()
                .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentPnl1Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(instructorLastnameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(studentPnl1Layout.createSequentialGroup()
                                .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(instructorFirstnameFld, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(studentPnl1Layout.createSequentialGroup()
                                        .addComponent(instructorIdFld, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(38, 38, 38)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(instructorAgeFld, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                                    .addComponent(instructorGenderFld, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)))))
                    .addGroup(studentPnl1Layout.createSequentialGroup()
                        .addGap(389, 389, 389)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(studentPnl1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 896, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(studentPnl1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(instructorSearchFld, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(instructorAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(instructorDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(instructorUpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        studentPnl1Layout.setVerticalGroup(
            studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentPnl1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addGap(54, 54, 54)
                .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorAgeFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorIdFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorLastnameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorGenderFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorFirstnameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addGroup(studentPnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(instructorSearchFld, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(instructorUpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout instructorPnlLayout = new javax.swing.GroupLayout(instructorPnl);
        instructorPnl.setLayout(instructorPnlLayout);
        instructorPnlLayout.setHorizontalGroup(
            instructorPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(instructorPnlLayout.createSequentialGroup()
                .addGap(0, 4, Short.MAX_VALUE)
                .addComponent(studentPnl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 5, Short.MAX_VALUE))
        );
        instructorPnlLayout.setVerticalGroup(
            instructorPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, instructorPnlLayout.createSequentialGroup()
                .addGap(0, 7, Short.MAX_VALUE)
                .addComponent(studentPnl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        parentPnl.add(instructorPnl, "card2");

        studentPnl.setBackground(new java.awt.Color(171, 208, 244));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 32)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Student");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Age :");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Id Number :");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Lastname :");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Gender :");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Firstname :");

        studentUpdateBtn.setBackground(new java.awt.Color(50, 153, 255));
        studentUpdateBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentUpdateBtn.setText("Update");
        studentUpdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentUpdateBtnActionPerformed(evt);
            }
        });

        studentAddBtn.setBackground(new java.awt.Color(234, 138, 138));
        studentAddBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentAddBtn.setText("Add");
        studentAddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentAddBtnActionPerformed(evt);
            }
        });

        studentDeleteBtn.setBackground(new java.awt.Color(103, 239, 93));
        studentDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentDeleteBtn.setText("Delete");
        studentDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentDeleteBtnActionPerformed(evt);
            }
        });

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Number", "Lastname", "Firstname", "Age", "Gender", "Username", "Password"
            }
        ));
        studentTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                studentTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(studentTable);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("Search Name :");

        studentSearchFld.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        studentSearchFld.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                studentSearchFldKeyPressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Password :");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel23.setText("Username :");

        javax.swing.GroupLayout studentPnlLayout = new javax.swing.GroupLayout(studentPnl);
        studentPnl.setLayout(studentPnlLayout);
        studentPnlLayout.setHorizontalGroup(
            studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentPnlLayout.createSequentialGroup()
                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentPnlLayout.createSequentialGroup()
                        .addGap(389, 389, 389)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(studentPnlLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 896, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(studentPnlLayout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(studentPnlLayout.createSequentialGroup()
                                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(studentPnlLayout.createSequentialGroup()
                                        .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(studentPnlLayout.createSequentialGroup()
                                                .addComponent(studentIdFld, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(38, 38, 38)
                                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(studentPnlLayout.createSequentialGroup()
                                                .addComponent(studentFirstnameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(38, 38, 38)
                                                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(studentAgeFld, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(studentPasswordFld, javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(studentUsernameFld, javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(studentGenderFld, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE))
                                            .addGroup(studentPnlLayout.createSequentialGroup()
                                                .addComponent(studentAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(studentDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(studentUpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addComponent(studentLastnameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(studentPnlLayout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(studentSearchFld, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(10, 15, Short.MAX_VALUE))
        );
        studentPnlLayout.setVerticalGroup(
            studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentPnlLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(54, 54, 54)
                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studentAgeFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studentIdFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studentLastnameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studentGenderFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentPnlLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentFirstnameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(studentPnlLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(studentUsernameFld, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studentPasswordFld, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentPnlLayout.createSequentialGroup()
                        .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentSearchFld, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentPnlLayout.createSequentialGroup()
                        .addGroup(studentPnlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(studentAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentUpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        parentPnl.add(studentPnl, "card4");

        jMenuBar1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jMenu1.setText("Manage Record");

        jMenuItem1.setText("Student");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Instructor");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Subject");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Load Subject");

        jMenuItem5.setText("Create Grade");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem5);

        jMenuItem6.setText("Enroll");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem6);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(parentPnl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(parentPnl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        parentPnl.removeAll();
        parentPnl.add(studentPnl);
        parentPnl.repaint();
        parentPnl.revalidate();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        parentPnl.removeAll();
        parentPnl.add(instructorPnl);
        parentPnl.repaint();
        parentPnl.revalidate();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        parentPnl.removeAll();
        parentPnl.add(subjectPnl);
        parentPnl.repaint();
        parentPnl.revalidate();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void studentAddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentAddBtnActionPerformed
        try
        { 
            int id = Integer.parseInt(studentIdFld.getText());
            String lastname =studentLastnameFld.getText();
            String firstname = studentFirstnameFld.getText();
            int age = Integer.parseInt(studentAgeFld.getText());
            String gender = studentGenderFld.getText();
            String username = studentUsernameFld.getText();
            String password = studentPasswordFld.getText();
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("INSERT INTO student (idNum, lastname, fisrtname, age, gender, username, password) VALUES(?,?,?,?,?,?,?)");
            ps.setInt(1, id);
            ps.setString(2, lastname);
            ps.setString(3, firstname);
            ps.setInt(4, age);
            ps.setString(5, gender);
            ps.setString(6, username);
            ps.setString(7, password);
            
            int check = ps.executeUpdate();
            
            if(check == 1){
                JOptionPane.showMessageDialog(null,"Successfully Added!!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,"Not Added!!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            studentIdFld.setText("");
            studentLastnameFld.setText("");
            studentFirstnameFld.setText("");
            studentAgeFld.setText("");
            studentGenderFld.setText("");
            studentUsernameFld.setText("");
            studentPasswordFld.setText("");
            studentShowData();
            
            
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_studentAddBtnActionPerformed

    private void studentDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentDeleteBtnActionPerformed
       try{
           int id = Integer.parseInt(studentIdFld.getText());
           
           conn = DbConnection.getConnection();
           ps = conn.prepareStatement("DELETE FROM student WHERE idNum = ?");
           ps.setInt(1, id);
           int check = ps.executeUpdate();
            
            if(check == 1)
            {
                JOptionPane.showMessageDialog(null, "Successfully Deleted!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Can't Delete", "Message", JOptionPane.ERROR_MESSAGE);
            }
            studentIdFld.setText("");
            studentLastnameFld.setText("");
            studentFirstnameFld.setText("");
            studentAgeFld.setText("");
            studentGenderFld.setText("");
            studentUsernameFld.setText("");
            studentPasswordFld.setText("");
            studentShowData();
       }
       catch(Exception ex){
           JOptionPane.showMessageDialog(null, ex.getMessage());
       }
    }//GEN-LAST:event_studentDeleteBtnActionPerformed

    private void studentUpdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentUpdateBtnActionPerformed
        try
        {
            int id = Integer.parseInt(studentIdFld.getText());
            String lastname =studentLastnameFld.getText();
            String firstname = studentFirstnameFld.getText();
            int age = Integer.parseInt(studentAgeFld.getText());
            String gender = studentGenderFld.getText();
            String username = studentUsernameFld.getText();
            String password = studentPasswordFld.getText();
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("UPDATE student SET lastname = ?, fisrtname = ?, age = ?, gender = ?, username = ? , password = ?  WHERE idNum = ?");
            ps.setString(1, lastname);
            ps.setString(2, firstname);
            ps.setInt(3, age);
            ps.setString(4, gender);
            ps.setString(5, username);
            ps.setString(6, password);
            ps.setInt(7, id);
            
            int check = ps.executeUpdate();
            
            if(check == 1)
            {
                JOptionPane.showMessageDialog(null, "Successfully Update!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Can't Update!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            studentIdFld.setText("");
            studentLastnameFld.setText("");
            studentFirstnameFld.setText("");
            studentAgeFld.setText("");
            studentGenderFld.setText("");
            studentUsernameFld.setText("");
            studentPasswordFld.setText("");
            studentShowData();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_studentUpdateBtnActionPerformed

    private void instructorAddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_instructorAddBtnActionPerformed
        try
        { 
            int id = Integer.parseInt(instructorIdFld.getText());
            String lastname =instructorLastnameFld.getText();
            String firstname = instructorFirstnameFld.getText();
            int age = Integer.parseInt(instructorAgeFld.getText());
            String gender = instructorGenderFld.getText();
            
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("INSERT INTO instructor (idInstructor, lastname, firstname, age, gender) VALUES(?,?,?,?,?)");
            ps.setInt(1, id);
            ps.setString(2, lastname);
            ps.setString(3, firstname);
            ps.setInt(4, age);
            ps.setString(5, gender);
            
            
            int check = ps.executeUpdate();
            
            if(check == 1){
                JOptionPane.showMessageDialog(null,"Successfully Added!!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,"Not Added!!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            instructorIdFld.setText("");
            instructorLastnameFld.setText("");
            instructorFirstnameFld.setText("");
            instructorAgeFld.setText("");
            instructorGenderFld.setText("");
            instructorShowData();
            
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_instructorAddBtnActionPerformed

    private void instructorDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_instructorDeleteBtnActionPerformed
        try{
            int id = Integer.parseInt(instructorIdFld.getText());
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("DELETE FROM instructor WHERE idInstructor = ?");
            ps.setInt(1, id);
            
            int check = ps.executeUpdate();
            
            if(check == 1)
            {
                JOptionPane.showMessageDialog(null, "Successfully Deleted!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Can't Delete", "Message", JOptionPane.ERROR_MESSAGE);
            }
            instructorIdFld.setText("");
            instructorLastnameFld.setText("");
            instructorFirstnameFld.setText("");
            instructorAgeFld.setText("");
            instructorGenderFld.setText("");
            instructorShowData();
            
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_instructorDeleteBtnActionPerformed

    private void instructorUpdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_instructorUpdateBtnActionPerformed
        try
        { 
            int id = Integer.parseInt(instructorIdFld.getText());
            String lastname =instructorLastnameFld.getText();
            String firstname = instructorFirstnameFld.getText();
            int age = Integer.parseInt(instructorAgeFld.getText());
            String gender = instructorGenderFld.getText();
            
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("UPDATE instructor set lastname = ?, firstname = ?, age = ?, gender = ? WHERE idInstructor = ?");
            ps.setString(1, lastname);
            ps.setString(2, firstname);
            ps.setInt(3, age);
            ps.setString(4, gender);
           
            ps.setInt(5, id);
            
            int check = ps.executeUpdate();
            
            if(check == 1){
                JOptionPane.showMessageDialog(null,"Successfully Update!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,"Not Update!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            instructorIdFld.setText("");
            instructorLastnameFld.setText("");
            instructorFirstnameFld.setText("");
            instructorAgeFld.setText("");
            instructorGenderFld.setText("");
            instructorShowData();
            
            
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_instructorUpdateBtnActionPerformed

    private void subjectAddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectAddBtnActionPerformed
        try
        {
            int code = Integer.parseInt(subjectCode.getText());
            String des = subjectDescriptive.getText();
            int unit = Integer.parseInt(subjectUnits.getText());
            String pre = subjectPre.getText();
            String credit = subjectCredit.getText();
            
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("INSERT into subject (subjectCode, descriptive, units, prereq, credit) VALUES(?,?,?,?,?)");
            ps.setInt(1, code);
            ps.setString(2, des);
            ps.setInt(3, unit);
            ps.setString(4, pre);
            ps.setString(5, credit);
            
            int check = ps.executeUpdate();
            
            if(check == 1){
                JOptionPane.showMessageDialog(null,"Successfully Added!!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,"Not Added!!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            subjectCode.setText("");
            subjectDescriptive.setText("");
            subjectUnits.setText("");
            subjectPre.setText("");
            subjectCredit.setText("");
            subjectShowData();
            
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_subjectAddBtnActionPerformed

    private void subjectDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectDeleteBtnActionPerformed
        try{
            int code = Integer.parseInt(subjectCode.getText());
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("DELETE FROM subject WHERE subjectCode = ?");
            ps.setInt(1, code);
            
            int check = ps.executeUpdate();
            
            if(check == 1)
            {
                JOptionPane.showMessageDialog(null, "Successfully Deleted!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Can't Delete", "Message", JOptionPane.ERROR_MESSAGE);
            }
            subjectCode.setText("");
            subjectDescriptive.setText("");
            subjectUnits.setText("");
            subjectPre.setText("");
            subjectCredit.setText("");
            subjectShowData();
            
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_subjectDeleteBtnActionPerformed

    private void subjectUpdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectUpdateBtnActionPerformed
        try{
            int code = Integer.parseInt(subjectCode.getText());
            String des = subjectDescriptive.getText();
            int unit = Integer.parseInt(subjectUnits.getText());
            String pre = subjectPre.getText();
            String credit = subjectCredit.getText();
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("UPDATE subject set descriptive = ?, units= ?, prereq= ?, credit= ? WHERE subjectCode = ?");
            ps.setString(1, des);
            ps.setInt(2, unit);
            ps.setString(3, pre);
            ps.setString(4, credit);
            ps.setInt(5, code);
            
            int check = ps.executeUpdate();
            
            if(check == 1){
                JOptionPane.showMessageDialog(null,"Successfully Update!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,"Not Update!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            subjectCode.setText("");
            subjectDescriptive.setText("");
            subjectUnits.setText("");
            subjectPre.setText("");
            subjectCredit.setText("");
             subjectShowData();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_subjectUpdateBtnActionPerformed

    private void subjectSearchFldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_subjectSearchFldKeyPressed
        DefaultTableModel model = (DefaultTableModel) subjectTable.getModel();
        final TableRowSorter<TableModel> trs = new TableRowSorter<>(model);
        subjectTable.setRowSorter(trs);
        
        String search = subjectSearchFld.getText();
        if(search.length() == 0){
            trs.setRowFilter(null);
        }
        else{
            trs.setRowFilter(RowFilter.regexFilter(search));;
        }
    }//GEN-LAST:event_subjectSearchFldKeyPressed

    private void instructorSearchFldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_instructorSearchFldKeyPressed
        DefaultTableModel model = (DefaultTableModel) instructorTable.getModel();
        final TableRowSorter<TableModel> trs = new TableRowSorter<>(model);
        instructorTable.setRowSorter(trs);
        
        String search = instructorSearchFld.getText();
        if(search.length() == 0){
            trs.setRowFilter(null);
        }
        else{
            trs.setRowFilter(RowFilter.regexFilter(search));;
        }
    }//GEN-LAST:event_instructorSearchFldKeyPressed

    private void studentSearchFldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_studentSearchFldKeyPressed
        DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
        final TableRowSorter<TableModel> trs = new TableRowSorter<>(model);
        studentTable.setRowSorter(trs);
        
        String search = studentSearchFld.getText();
        if(search.length() == 0){
            trs.setRowFilter(null);
        }
        else{
            trs.setRowFilter(RowFilter.regexFilter(search));;
        }
    }//GEN-LAST:event_studentSearchFldKeyPressed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        EnrollFrame ef = new EnrollFrame();
        ef.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        CreateGrade cr = new CreateGrade();
        cr.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void instructorTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_instructorTableMouseClicked
        DefaultTableModel dtm = (DefaultTableModel) instructorTable.getModel();
        
        String id = dtm.getValueAt(instructorTable.getSelectedRow(), 0).toString();
        String lastname = dtm.getValueAt(instructorTable.getSelectedRow(), 1).toString();
        String firstname = dtm.getValueAt(instructorTable.getSelectedRow(), 2).toString();
        String age = dtm.getValueAt(instructorTable.getSelectedRow(), 3).toString();
        String gender = dtm.getValueAt(instructorTable.getSelectedRow(), 4).toString();
        
        instructorIdFld.setText(id);
        instructorLastnameFld.setText(lastname);
        instructorFirstnameFld.setText(firstname);
        instructorAgeFld.setText(age);
        instructorGenderFld.setText(gender);
    }//GEN-LAST:event_instructorTableMouseClicked

    private void subjectTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_subjectTableMouseClicked
         DefaultTableModel dtm = (DefaultTableModel) subjectTable.getModel();
        
        String code = dtm.getValueAt(subjectTable.getSelectedRow(), 0).toString();
        String des = dtm.getValueAt(subjectTable.getSelectedRow(), 1).toString();
        String units = dtm.getValueAt(subjectTable.getSelectedRow(), 2).toString();
        String pre = dtm.getValueAt(subjectTable.getSelectedRow(), 3).toString();
        String credit = dtm.getValueAt(subjectTable.getSelectedRow(), 4).toString();
        
        subjectCode.setText(code);
        subjectDescriptive.setText(des);
        subjectUnits.setText(units);
        subjectPre.setText(pre);
        subjectCredit.setText(credit);
        
    }//GEN-LAST:event_subjectTableMouseClicked

    private void studentTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_studentTableMouseClicked
        DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
        
        String id = dtm.getValueAt(studentTable.getSelectedRow(), 0).toString();
        String lastname = dtm.getValueAt(studentTable.getSelectedRow(), 1).toString();
        String firstname = dtm.getValueAt(studentTable.getSelectedRow(), 2).toString();
        String age = dtm.getValueAt(studentTable.getSelectedRow(), 3).toString();
        String gender = dtm.getValueAt(studentTable.getSelectedRow(), 4).toString();
        String user = dtm.getValueAt(studentTable.getSelectedRow(), 5).toString();
        String pass = dtm.getValueAt(studentTable.getSelectedRow(), 6).toString();
        
        studentIdFld.setText(id);
        studentLastnameFld.setText(lastname);
        studentFirstnameFld.setText(firstname);
        studentAgeFld.setText(age);
        studentGenderFld.setText(gender);
        studentUsernameFld.setText(user);
        studentPasswordFld.setText(pass);
    }//GEN-LAST:event_studentTableMouseClicked

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton instructorAddBtn;
    public javax.swing.JTextField instructorAgeFld;
    public javax.swing.JButton instructorDeleteBtn;
    public javax.swing.JTextField instructorFirstnameFld;
    public javax.swing.JTextField instructorGenderFld;
    public javax.swing.JTextField instructorIdFld;
    public javax.swing.JTextField instructorLastnameFld;
    public javax.swing.JPanel instructorPnl;
    public javax.swing.JTextField instructorSearchFld;
    public javax.swing.JTable instructorTable;
    public javax.swing.JButton instructorUpdateBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPanel parentPnl;
    public javax.swing.JButton studentAddBtn;
    public javax.swing.JTextField studentAgeFld;
    public javax.swing.JButton studentDeleteBtn;
    public javax.swing.JTextField studentFirstnameFld;
    public javax.swing.JTextField studentGenderFld;
    public javax.swing.JTextField studentIdFld;
    public javax.swing.JTextField studentLastnameFld;
    public javax.swing.JTextField studentPasswordFld;
    private javax.swing.JPanel studentPnl;
    private javax.swing.JPanel studentPnl1;
    public javax.swing.JTextField studentSearchFld;
    public javax.swing.JTable studentTable;
    public javax.swing.JButton studentUpdateBtn;
    public javax.swing.JTextField studentUsernameFld;
    public javax.swing.JButton subjectAddBtn;
    public javax.swing.JTextField subjectCode;
    public javax.swing.JTextField subjectCredit;
    public javax.swing.JButton subjectDeleteBtn;
    public javax.swing.JTextField subjectDescriptive;
    public javax.swing.JPanel subjectPnl;
    public javax.swing.JTextField subjectPre;
    public javax.swing.JTextField subjectSearchFld;
    public javax.swing.JTable subjectTable;
    public javax.swing.JTextField subjectUnits;
    public javax.swing.JButton subjectUpdateBtn;
    // End of variables declaration//GEN-END:variables
}
