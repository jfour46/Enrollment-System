
package AdminPackage;

import enrollmentsystem.DbConnection;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;


public class CreateGrade extends javax.swing.JFrame {

    
    public CreateGrade() {
        initComponents();
        studentComboData();
        subjectComboData();
        instructorComboData();
        showGradeData();
    }
    Connection conn = null;
    PreparedStatement ps;
    ResultSet rs;
    

    public void studentComboData(){
        try
        {
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("SELECT * FROM student");
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                cgStudentIdCombo.addItem(rs.getString("idNum"));
                
                
            }
            cgStudentIdCombo.setSelectedIndex(-1);
            
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    public void subjectComboData(){
        try
        {
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("SELECT * FROM subject");
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                cgSubjectCodeCombo.addItem(rs.getString("subjectCode"));
                
                
            }
            cgSubjectCodeCombo.setSelectedIndex(-1);
            
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    public void instructorComboData(){
        try
        {
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("SELECT * FROM instructor");
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                cgInstructorIdCombo.addItem(rs.getString("idInstructor"));
                
                
            }
            cgInstructorIdCombo.setSelectedIndex(-1);
            
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    public void showGradeData(){
        DefaultTableModel dtm = (DefaultTableModel) cgTable.getModel();
        dtm.setRowCount(0);
        
        try
        {
            conn = DbConnection.getConnection();
            Statement s = conn.createStatement();
            rs = s.executeQuery("SELECT * FROM gradetbl");
            
            while(rs.next())
            {
                Vector v = new Vector();
                v.add(rs.getString(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                
                
                dtm.addRow(v);
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        cgTable = new javax.swing.JTable();
        cgStudentIdCombo = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cgSubjectCodeCombo = new javax.swing.JComboBox<>();
        cgInstructorIdCombo = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cgGradeFld = new javax.swing.JTextField();
        cgAddBtn = new javax.swing.JButton();
        cgDeleteBtn = new javax.swing.JButton();
        cgUpdateBtn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(171, 208, 244));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Create Grade");

        cgTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Student Id", "Subject Code", "Instructor Id", "Grade"
            }
        ));
        cgTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cgTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(cgTable);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Student ID :");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Instructor ID :");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Subject Code :");

        cgSubjectCodeCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cgSubjectCodeComboActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Grade :");

        cgAddBtn.setBackground(new java.awt.Color(234, 138, 138));
        cgAddBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cgAddBtn.setText("Add Grade");
        cgAddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cgAddBtnActionPerformed(evt);
            }
        });

        cgDeleteBtn.setBackground(new java.awt.Color(103, 239, 93));
        cgDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cgDeleteBtn.setText("Delete Grade");
        cgDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cgDeleteBtnActionPerformed(evt);
            }
        });

        cgUpdateBtn.setBackground(new java.awt.Color(50, 153, 255));
        cgUpdateBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cgUpdateBtn.setText("Update Grade");
        cgUpdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cgUpdateBtnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("ID :");

        jButton1.setBackground(new java.awt.Color(95, 239, 93));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setText("<");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cgStudentIdCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(cgSubjectCodeCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(94, 94, 94)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cgGradeFld, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cgInstructorIdCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(cgAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cgDeleteBtn)
                        .addGap(19, 19, 19)
                        .addComponent(cgUpdateBtn)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cgInstructorIdCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cgGradeFld, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cgStudentIdCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cgSubjectCodeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cgAddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cgDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cgUpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cgAddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cgAddBtnActionPerformed
        try
        {
            int studentId = Integer.parseInt(cgStudentIdCombo.getSelectedItem().toString());
            int subjectCode = Integer.parseInt(cgSubjectCodeCombo.getSelectedItem().toString());
            int instructorId = Integer.parseInt(cgInstructorIdCombo.getSelectedItem().toString());
            int grade = Integer.parseInt(cgGradeFld.getText());
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("INSERT INTO gradetbl (studentid, subjectcode, instructorid, grade) VALUES (?,?,?,?)");
            ps.setInt(1, studentId);
            ps.setInt(2, subjectCode);
            ps.setInt(3, instructorId);
            ps.setInt(4, grade);
            
            int check = ps.executeUpdate();
            
            if(check == 1)
            {
                JOptionPane.showMessageDialog(null, "Successfully Insert Grade!!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Not Insert Grade!!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            showGradeData();
            cgSubjectCodeCombo.setSelectedIndex(-1);
            cgInstructorIdCombo.setSelectedIndex(-1);
            cgGradeFld.setText("");
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_cgAddBtnActionPerformed

    private void cgDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cgDeleteBtnActionPerformed
        try
        {
            int id = Integer.parseInt(jLabel7.getText());
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("DELETE FROM gradetbl WHERE id = ?");
            ps.setInt(1, id);
            
            int check = ps.executeUpdate();
            
            if(check == 1){
                JOptionPane.showMessageDialog(null, "Successfully Delete Grade!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null, "Not Delete a Grade have an ERROR!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            
            showGradeData();
           
            
            jLabel7.setText("");
            cgGradeFld.setText("");
            
            
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_cgDeleteBtnActionPerformed

    private void cgTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cgTableMouseClicked
      DefaultTableModel dtm = (DefaultTableModel) cgTable.getModel();
        
        String id = dtm.getValueAt(cgTable.getSelectedRow(), 0).toString();
        String grade = dtm.getValueAt(cgTable.getSelectedRow(), 4).toString();
        
        cgGradeFld.setText(grade);
        jLabel7.setText(id);
        cgSubjectCodeCombo.setSelectedIndex(-1);
        cgInstructorIdCombo.setSelectedIndex(-1);
        cgStudentIdCombo.setSelectedIndex(-1);
        
    }//GEN-LAST:event_cgTableMouseClicked

    private void cgUpdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cgUpdateBtnActionPerformed
        try
        {
            int idF = Integer.parseInt(jLabel7.getText());
            int gr = Integer.parseInt(cgGradeFld.getText());
            
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("UPDATE gradetbl set grade = ? WHERE id = ?");
            ps.setInt(1, gr);
            ps.setInt(2, idF);
            
            
            int check = ps.executeUpdate();
            
            if(check == 1)
            {
                JOptionPane.showMessageDialog(null,"Successfully Update!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Not Update!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            showGradeData();
            cgGradeFld.setText("");
            
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_cgUpdateBtnActionPerformed

    private void cgSubjectCodeComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cgSubjectCodeComboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cgSubjectCodeComboActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        AdminFrame ar = new AdminFrame();
        ar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cgAddBtn;
    private javax.swing.JButton cgDeleteBtn;
    private javax.swing.JTextField cgGradeFld;
    private javax.swing.JComboBox<String> cgInstructorIdCombo;
    private javax.swing.JComboBox<String> cgStudentIdCombo;
    private javax.swing.JComboBox<String> cgSubjectCodeCombo;
    private javax.swing.JTable cgTable;
    private javax.swing.JButton cgUpdateBtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
