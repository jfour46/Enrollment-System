
package StudentPackage;

import enrollmentsystem.DbConnection;
import java.awt.Image;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class ViewGradeFrame extends javax.swing.JFrame {

    
    public ViewGradeFrame() {
        initComponents();
    }
    Connection conn = null;
    PreparedStatement ps;
    ResultSet rs;
    
    InfoFrame inF = new InfoFrame();
    
    int idF;
    
    public void showInfo() {
        try {
            conn = DbConnection.getConnection();
            
            
            idF = Integer.parseInt(gradeIdLabel.getText());
            ps = conn.prepareStatement("SELECT idNum,lastname,fisrtname,age,gender FROM student WHERE idNum = ?");
            
            ps.setInt(1, idF);
            
            rs = ps.executeQuery();
            
            if(rs.next()) {
                
                inF.infoIdLbl.setText(rs.getString(1));
                inF.infoLastnameLbl.setText(rs.getString(2));
                inF.infoFirstnameLbl.setText(rs.getString(3));
                inF.infoAgeLbl.setText(rs.getString(4));
                inF.infoGenderLbl.setText(rs.getString(5));
                
                ps = conn.prepareStatement("SELECT course,year,section,ay,semester FROM ernolltbl WHERE studentId = ?");
                ps.setInt(1, idF);
                
                rs = ps.executeQuery();
                
                if(rs.next()){
                    inF.infoCourseLbl.setText(rs.getString(1));
                    inF.infoYearLbl.setText(rs.getString(2));
                    inF.infoSectionLbl.setText(rs.getString(3));
                    inF.infoAYLbl.setText(rs.getString(4));
                    inF.infoSemesterLbl.setText(rs.getString(5));
                    
                        ps = conn.prepareStatement("SELECT course,year,section,ay,semester FROM ernolltbl WHERE studentId = ?");
                        ps.setInt(1, idF);

                        rs = ps.executeQuery();

                        while(rs.next()){
                            inF.infoCourseLbl.setText(rs.getString(1));
                            inF.infoYearLbl.setText(rs.getString(2));
                            inF.infoSectionLbl.setText(rs.getString(3));
                            inF.infoAYLbl.setText(rs.getString(4));
                            inF.infoSemesterLbl.setText(rs.getString(5));

                        }
                        
                        
                        ps = conn.prepareStatement("SELECT * FROM ernolltbl WHERE studentId = ?");
                        ps.setInt(1, idF);

                        rs = ps.executeQuery();

                        while(rs.next())
                        {
                            loadImageInPosPanel();
                        }
                }
            }
        }catch(Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
    }
    public void showDataFromEnroll(){
        try {
            conn = DbConnection.getConnection();
            
            
            idF = Integer.parseInt(gradeIdLabel.getText());
            
                
                ps = conn.prepareStatement("SELECT course,year,section,ay,semester FROM ernolltbl WHERE studentId = ?");
                ps.setInt(1, idF);
                
                rs = ps.executeQuery();
                
                if(rs.next()){
                    inF.infoCourseLbl.setText(rs.getString(1));
                    inF.infoYearLbl.setText(rs.getString(2));
                    inF.infoSectionLbl.setText(rs.getString(3));
                    inF.infoAYLbl.setText(rs.getString(4));
                    inF.infoSemesterLbl.setText(rs.getString(5));
                
            }
        }catch(Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
    }
    public void loadImageInPosPanel(){
        try {
            byte[] imgData = rs.getBytes("image");
            ImageIcon imgIcon1 = new ImageIcon(imgData);
            Image img = imgIcon1.getImage();
            Image img2 = img.getScaledInstance(185, 143, Image.SCALE_SMOOTH);
            ImageIcon imgIcon2 = new ImageIcon(img2);
            
            inF.infoPhotoLbl.setIcon(imgIcon2);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,ex);
            
        }
    }
    
    public void showID() {
        try {
            
            int id = Integer.parseInt(gradeIdLabel.getText());
            conn = DbConnection.getConnection();
            
            ps = conn.prepareStatement("SELECT * FROM student WHERE idNum = ?");
            
            ps.setInt(1, id);
            
            rs = ps.executeQuery();
            
            if(rs.next()) {
                
                ViewGrade.viewIDFld.setText(rs.getString(1));
            }
        }catch(Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        gradeNameLbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        gradeIdLabel = new javax.swing.JLabel();
        gradeShowInforBtn = new javax.swing.JButton();
        gradeViewBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(171, 208, 244));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        jLabel2.setText("Hi! ");

        gradeNameLbl.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText(" ID Number : ");

        gradeIdLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        gradeShowInforBtn.setBackground(new java.awt.Color(234, 138, 138));
        gradeShowInforBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        gradeShowInforBtn.setText("Show Info.");
        gradeShowInforBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gradeShowInforBtnActionPerformed(evt);
            }
        });

        gradeViewBtn.setBackground(new java.awt.Color(50, 153, 255));
        gradeViewBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        gradeViewBtn.setText("View Grade");
        gradeViewBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gradeViewBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(gradeNameLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(gradeShowInforBtn)
                                .addGap(74, 74, 74)
                                .addComponent(gradeViewBtn))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(gradeIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gradeNameLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gradeIdLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(77, 77, 77)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gradeShowInforBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gradeViewBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(90, 90, 90))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void gradeShowInforBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gradeShowInforBtnActionPerformed
        inF.setVisible(true);
        this.dispose();
        showInfo();
//        showDataFromEnroll();
    }//GEN-LAST:event_gradeShowInforBtnActionPerformed

    private void gradeViewBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gradeViewBtnActionPerformed
        ViewGrade vg = new ViewGrade();
        vg.setVisible(true);
        showID();
        
        
        
        
        
    }//GEN-LAST:event_gradeViewBtnActionPerformed

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JLabel gradeIdLabel;
    public static javax.swing.JLabel gradeNameLbl;
    private javax.swing.JButton gradeShowInforBtn;
    private javax.swing.JButton gradeViewBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
