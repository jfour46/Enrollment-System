package enrollmentsystem;

public class MainClass {
    public static void main(String[] args){
        OptionFrame opFrame = new OptionFrame();
        opFrame.setVisible(true);
        
    }
}
