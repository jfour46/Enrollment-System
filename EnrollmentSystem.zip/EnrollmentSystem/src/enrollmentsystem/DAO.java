
package enrollmentsystem;

import AdminPackage.AdminFrame;
import AdminPackage.AdminLogin;
import javax.swing.JOptionPane;
import java.sql.*;

public class DAO {
    
    AdminFrame adFrame = new AdminFrame();
    AdminLogin adminLog = new AdminLogin();
    Connection conn=null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void studentAddRecord(){
        try
        { 
            int id = Integer.parseInt(adFrame.studentIdFld.getText());
            String lastname = adFrame.studentLastnameFld.getText();
            String firstname = adFrame.studentFirstnameFld.getText();
            int age = Integer.parseInt(adFrame.studentAgeFld.getText());
            String gender = adFrame.studentGenderFld.getText();
            String username = adFrame.studentUsernameFld.getText();
            String password = adFrame.studentPasswordFld.getText();
            
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("INSERT INTO student (idNum, lastname, fisrtname, age, gender, username, password) VALUES(?,?,?,?,?,?,?)");
            ps.setInt(1, id);
            ps.setString(2, lastname);
            ps.setString(3, firstname);
            ps.setInt(4, age);
            ps.setString(5, gender);
            ps.setString(6, username);
            ps.setString(7, password);
            
            int check = ps.executeUpdate();
            
            if(check == 1){
                JOptionPane.showMessageDialog(null,"Successfully Added!!", "Message", JOptionPane.PLAIN_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,"Not Added!!", "Message", JOptionPane.ERROR_MESSAGE);
            }
            
            
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
}
